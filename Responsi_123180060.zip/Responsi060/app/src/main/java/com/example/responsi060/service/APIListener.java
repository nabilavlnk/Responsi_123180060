package com.example.responsi060.service;

public interface APIListener<T> {
    void onSuccess(T body);
    void onFailed(String message);
}
